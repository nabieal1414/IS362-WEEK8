import pandas as pd
import seaborn as sns
import requests
import matplotlib.pyplot as plt

# 1. Load the data into a pandas DataFrame
url = "https://archive.ics.uci.edu/ml/machine-learning-databases/auto-mpg/auto-mpg.data"
column_names = ['mpg', 'cylinders', 'displacement', 'horsepower', 'weight',
                'acceleration', 'model_year', 'origin', 'car_name']
df = pd.read_csv(url, delim_whitespace=True, names=column_names)

# 2. Review the data and the provided data set description
print(df.head())
response = requests.get("https://archive.ics.uci.edu/ml/datasets/Auto+MPG")
description = response.content.decode('utf-8')
print(description)

# 3. Rename columns using the attribute information provided in auto-mpg.names
df.rename(columns={'cylinders': 'num_of_cylinders', 'displacement': 'engine_displacement',
                   'horsepower': 'horsepower', 'weight': 'vehicle_weight',
                   'acceleration': 'acceleration_rate', 'model_year': 'manufacture_year',
                   'origin': 'country_of_origin', 'car_name': 'vehicle_name'}, inplace=True)

# 4. Replace missing values '?' with NaN and convert column to numeric
df['horsepower'] = df['horsepower'].replace('?', pd.NaT)
df['horsepower'] = pd.to_numeric(df['horsepower'], errors='coerce')

# 5. Convert origin column values to country names
df['country_of_origin'] = df['country_of_origin'].replace({1: 'USA', 2: 'Asia', 3: 'Europe'})

# 6. Create a bar chart that shows the distribution for cylinders
sns.countplot(x='num_of_cylinders', data=df)
plt.title('Distribution of Cylinders')
plt.xlabel('Number of Cylinders')
plt.ylabel('Count')
plt.show()

# 7. Create a scatterplot that shows the relationship between horsepower and weight
sns.scatterplot(x='horsepower', y='vehicle_weight', data=df)
plt.title('Relationship Between Horsepower and Weight')
plt.xlabel('Horsepower')
plt.ylabel('Vehicle Weight')
plt.show()

# 8. Ask and answer an interesting question about the distribution of one of the variables or the relationship between two (or more!) of the variables in the Auto MPG dataset.
# Example: Is there a relationship between the fuel efficiency (mpg) of a car and its origin (country of manufacture)?
sns.boxplot(x='country_of_origin', y='mpg', data=df)
plt.title('Fuel Efficiency by Country of Origin')
plt.xlabel('Country of Origin')
plt.ylabel('Miles per Gallon')
plt.show()
